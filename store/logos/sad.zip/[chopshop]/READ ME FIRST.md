

 $$$$$$\  $$$$$$$\  $$$$$$$\  $$$$$$\ $$$$$$$$\       $$$$$$$\  $$$$$$$$\ $$\    $$\ 
$$  __$$\ $$  __$$\ $$  __$$\ \_$$  _|\__$$  __|      $$  __$$\ $$  _____|$$ |   $$ |
$$ /  $$ |$$ |  $$ |$$ |  $$ |  $$ |     $$ |         $$ |  $$ |$$ |      $$ |   $$ |
$$ |  $$ |$$$$$$$  |$$$$$$$\ |  $$ |     $$ |         $$ |  $$ |$$$$$\    \$$\  $$  |
$$ |  $$ |$$  __$$< $$  __$$\   $$ |     $$ |         $$ |  $$ |$$  __|    \$$\$$  / 
$$ |  $$ |$$ |  $$ |$$ |  $$ |  $$ |     $$ |         $$ |  $$ |$$ |        \$$$  /  
 $$$$$$  |$$ |  $$ |$$$$$$$  |$$$$$$\    $$ |         $$$$$$$  |$$$$$$$$\    \$  /   
 \______/ \__|  \__|\_______/ \______|   \__|         \_______/ \________|    \_/    


ChopShop/Scrapyard QBCore By Orbit Developments / Discord Adress: https://discord.com/invite/NC3NxVWKxk

Attention! : The instructions must be followed correctly and accurately.

-----------------------------------------------------------------------------------

1. Add the scripts to the file directory of your server and ensure them in server.cfg.

2. Backitems setup: paste this code under "local function LeaveApartment" in qb-apartments > client.lua

    exports['orbit-backitems']:toggleProps()

3. Add the following items to qbcore > shared > items.lua

   
4.You can throw the pictures in "Inventory Images" into your inventory

Not: If you want to use the npc dialogue you can configure it from orbit-dialogue config.lua. If you do not want to use it, use the config file in orbit-chopshop